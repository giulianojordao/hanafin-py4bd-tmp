idx = 0

while idx < 5:
    print(idx)
    idx += 1

print('프로그램 종료!')