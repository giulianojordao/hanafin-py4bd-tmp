# for Ex01
scope = [1, 2, 3, 4, 5]
for x in scope:
    print(x)

scope = list('abcde')
for x in scope:
    print(x)


