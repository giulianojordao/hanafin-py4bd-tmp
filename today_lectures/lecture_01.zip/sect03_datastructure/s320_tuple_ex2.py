width  = 20
height = 30
area = width * height
print('너비 :', width);  print('높이 :', height);
print('넓이 :', area)
print('-'*14)

data   = (15, 50)
width, height = data
area = width * height
print('너비 :', width);  print('높이 :', height);
print('넓이 :', area)

