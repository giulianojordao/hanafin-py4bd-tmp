#세트형 집합 연산자
a = set('abracadabra')
b = set('alacazam')

print('집합 a =', a);  print('집합 b =', b);
print('합집합, a | b =', a | b)
print('교집합, a & b =', a & b)
print('차집합, a - b =', a - b)
print('여집합, a ^ b =', a ^ b)

