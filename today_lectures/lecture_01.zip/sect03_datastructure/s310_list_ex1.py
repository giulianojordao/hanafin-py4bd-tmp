# 리스트형 선언 및 색인
bts_members = ['RM', '슈가', '진', '제이홉', '지민', '뷔', '정국']

# 변수의 타입 확인
print('멤버 :', bts_members)
print('타입 :', type(bts_members))
print('크기 :', len(bts_members))

print('\n리스트멤버 호출')
print(bts_members[0])
print(bts_members[1])
print(bts_members[2])
print(bts_members[3])

print('\n리스트멤버 호출(역순)')
print(bts_members[-1])
print(bts_members[-2])
print(bts_members[-3])
print(bts_members[-4])
