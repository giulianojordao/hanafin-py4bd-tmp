# Immutable 예제
hello = '안녕하세요!'    # hello 문자열형 변수 선언

print(hello)             # hello 값 확인
print(id(hello))         # hello 객체 식별자 확인

hello = '반값습니다!'    # hello 값 변경

print(hello)             # hello 값 확인
print(id(hello))         # hello 객체 식별자 확인