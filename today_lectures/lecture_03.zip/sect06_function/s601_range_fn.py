# range() 인자값 1개
result1 = list(range(10))

# range() 인자값 2개
result2 = list(range(5, 10))

# range() 인자값 3개
result3 = list(range(1, 10, 2))

print('range(10) \t\t= ', result1)
print('range(5,10) \t= ', result2)
print('range(1,10,2) \t= ', result3)
