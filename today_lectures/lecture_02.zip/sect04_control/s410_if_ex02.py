num_a = 100
num_b = 200

if num_a > num_b:
    print('숫자A가 숫자B보다 더 큰수입니다.')
else:
    print('숫자A는 숫자B와 같거나 더 작은수입니다.')

